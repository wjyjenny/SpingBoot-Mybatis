package com.huawang.demo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author xdl
 * @since 2021-02-26
 */
public class ListDemo {

    public static void main(String[] args) {
        List<Integer> arr = new ArrayList<>();
        System.out.println(arr);
    }
}
